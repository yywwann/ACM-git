#include <bits/stdc++.h>
using namespace std;

int main() {
    cout << (10000000000000 - 30) / 2 + 1 << endl;
    return 0;
}
