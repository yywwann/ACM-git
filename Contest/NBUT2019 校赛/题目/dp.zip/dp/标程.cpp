#include <iostream>
#include <cstdio> 
using namespace std;

long long a[55];
int T, n;

void f(){
	a[1] = 2;
	a[2] = 3;
	for(int i = 3; i <= 50; i++){
		a[i] = a[i-1] + a[i-2];
	}
}

int main(){
	freopen("In1.txt","r",stdin);
	freopen("Out1.txt","w",stdout);
	f();
	scanf("%d", &T);
	while(T--){
		scanf("%d", &n);
		printf("%lld\n", a[n] - 1);
	}
	return 0;
}
