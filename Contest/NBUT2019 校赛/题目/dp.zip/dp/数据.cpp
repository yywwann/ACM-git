#include <bits/stdc++.h>
#include <fstream>
#define FAST_IO ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define ll long long
using namespace std;

int main()
{
	mt19937_64 mt_rand(time(0));
	freopen("In1.txt","w",stdout);
	int T = 50;
	cout << T << endl;
	for(int i = T; i > 0; i--) {
		cout << i << endl;
	}
	
}
