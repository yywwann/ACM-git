#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 1e5 + 5;

struct segt {
    struct seg {
        int l, r;
        ll sum, lz, cnt;
        void update(ll val, ll cont) {
            sum += (r - l + 1) * val;
            sum += cont * (r - l) * (r - l + 1) / 2;
            lz += val;
            cnt += cont;
        }
    };

    #define lc x << 1
    #define rc x << 1 | 1
    #define mid ((t[x].l + t[x].r) / 2)

    ll * a;
    int left;
    seg t[N << 2];

    void modify(ll * arr) {a = arr;}
    void push_up(int x) {t[x].sum = t[lc].sum + t[rc].sum;}
    void push_down(int x) {
        ll lz = t[x].lz, cnt = t[x].cnt;
        t[lc].update(lz, cnt);
        t[rc].update(lz + cnt * (t[rc].l - t[lc].l), cnt);
        t[x].lz = t[x].cnt = 0;
    }
    void build(int x, int l, int r) {
        t[x] = seg({l, r, 0, 0, 0});
        if (l == r) {
            t[x].sum = a[l];
            return;
        }
        build(lc, l, mid);
        build(rc, mid + 1, r);
        push_up(x);
    }
    void update(int x, int l, int r) {
        int L(t[x].l), R(t[x].r);
        if (l <= L && R <= r) {
            t[x].update(t[x].l - left + 1, 1);
            return;
        }
        push_down(x);
        if (l <= mid) update(lc, l, r);
        if (r >  mid) update(rc, l, r);
        push_up(x);
    }
    ll query(int x, int l, int r) {
        int L(t[x].l), R(t[x].r);
        if (l <= L && R <= r) return t[x].sum;
        push_down(x);
        ll res = 0;
        if (l <= mid) res += query(lc, l, r);
        if (r >  mid) res += query(rc, l, r);
        return res;
    }
};

int n, m, op, l, r;
ll a[N];
segt tree;

void solve() {
    scanf("%d%d", &n, &m);
    for (int i = 1; i <= n; ++i)
        scanf("%lld", a+i);
    tree.modify(a);
    tree.build(1, 1, n);
    while (m--) {
        scanf("%d%d%d", &op, &l, &r);
        if (op == 1) {
            tree.left = l;
            tree.update(1, l, r);
        }
        else{
            printf("%lld\n", tree.query(1, l, r));
        }
    }
}

int main() {
    int T;
    cin >> T;
    while(T--) solve();
    return 0;
}