#include<bits/stdc++.h>
#define rep(x,a,b) for(int x=a;x<=b;x++)
using namespace std;
#define random(a,b) ((a)+rand()%((b)-(a)+1))
typedef long long ll;

stringstream ss;

int main( int argc, char *argv[] )
{ 
    int seed=time(NULL);
    if(argc)
    {
        ss.clear();
        ss<<argv[1];
        ss>>seed;
    }
    srand(seed);
    //ÒÔÉÏÎªËæ»úÊý³õÊ¼»¯£¬ÇëÎðÐÞ¸Ä
    //random(a,b)Éú³É[a,b]µÄËæ»úÕûÊý
    //ÒÔÏÂÐ´Äã×Ô¼ºµÄÊý¾ÝÉú³É´úÂë 
    int T = 1;
    cout << T << endl;
    mt19937 rand(time(0));
    for(int cas=1;cas<=T;cas++){
        int n = random(100000,100000), m = random(100000,100000);
        cout << n << ' ' << m << endl;
        for(int i=1;i<=n;i++) cout << random(1,100000) << " \n"[i==n];
        for(int i=1;i<=m;i++){
            int l = random(1,n);
            int r = random(l,n);
            cout << random(1,2) << ' ' << l << ' ' << r << endl;
        }
    }
    return 0;
}
