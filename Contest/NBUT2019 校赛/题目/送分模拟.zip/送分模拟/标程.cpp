#include <iostream>
#include <cstdio>
using namespace std;
int T, n, x, y, s, r, S, X, Y;
int sum;
bool check(int x, int y){
	return r * r >= (X - x) * (X - x) + (Y - y) * (Y - y);
}
int main(){
	freopen("In1.txt","r",stdin);
	freopen("Out1.txt","w",stdout);
	scanf("%d", &T);
	while(T--){
		scanf("%d%d", &n, &r);
		sum = 0;
		scanf("%d%d%d", &S, &X, &Y);
		for(int i = 1; i < n; i++){
			scanf("%d%d%d", &s, &x, &y);
			if(s < S && check(x, y)){
				sum++;
			}
		}
		printf("%d\n", sum);
	}
	return 0;
}
