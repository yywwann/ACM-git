#include <bits/stdc++.h>
#include <fstream>
#define FAST_IO ios_base::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define ll long long
using namespace std;

int main()
{
	mt19937_64 mt_rand(time(0));
	freopen("In1.txt","w",stdout);
	int T = 8;
	cout << T << endl;
	for(int i = 0; i < T; i++) {
		int n = mt_rand() % 1000 , r = mt_rand() % 1000;
		cout << n << " " << r << endl;
		for(int l = 0; l < n;l++){
			int s = mt_rand() % 1000 + 1;
			int x = mt_rand() % 1000 + 1;
			int y = mt_rand() % 1000 + 1;
			cout << s << " " << x << " " << y << endl;
		}
	}
	
}
