#include <bits/stdc++.h>
using namespace std;
const int N = 1005;
const int dx[] = {-1, 1, 0, 0};
const int dy[] = {0, 0, 1, -1};

struct node{int x, y, d;};
   
int n, m;
char p[N][N];
int vis[N][N];
deque<node> dq;
node now, tmp;
   
bool check(int x, int y) {
    if (x < 1 || x > n || y < 1 || y > m) return 0;
    if (vis[x][y]) return 0;
    return 1;
}
   
int bfs(int x, int y) {
    dq.push_back(node({x, y, 0}));
    vis[x][y] = 1;
    while(dq.size()) {
        node now = dq.front(); dq.pop_front();
        for (int i = 0; i < 4; i++) {
            tmp.x = now.x + dx[i];
            tmp.y = now.y + dy[i];
            if (check(tmp.x, tmp.y)) {
                if (p[tmp.x][tmp.y] == 'I' && p[now.x][now.y] != 'I') return now.d;
                if (p[tmp.x][tmp.y] == 'I') {
                    dq.push_front(node({tmp.x, tmp.y, 0}));
                }
                else if(p[tmp.x][tmp.y] == 'S') {
                    dq.push_front(node({tmp.x, tmp.y, now.d}));
                }
                else {
                    dq.push_back(node({tmp.x, tmp.y, now.d+1}));
                }
                vis[tmp.x][tmp.y] = 1;
            }
        }
    }
    return -1;
}
   
void init() {
    while(!dq.empty()) dq.pop_back();
    memset(vis, 0, sizeof vis);
}
   
void solve() {
    init();
    in >> n >> m;
    for (int i = 1; i <= n; i++) in >> (p[i] + 1);
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            if (p[i][j] == 'I') {
                out << bfs(i, j) << endl;
                return;
            }
        }
    }
}
   
int main() {
    int T;
    in >> T;
    while(T--) {
        solve();
    }
    return 0;
}