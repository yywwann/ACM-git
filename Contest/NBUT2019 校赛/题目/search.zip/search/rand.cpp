#include <bits/stdc++.h>
using namespace std;
#define random(a,b) ((a)+rand()%((b)-(a)+1))
const int N = 505;

char p[N][N];

int main(){
    ifstream in("in.txt");
    ofstream out("in.txt");
    int T = 5;
    mt19937 rand(time(0));
    out << T << endl;
    for(int i=1;i<=5;i++){
        for(int i=1;i<=500;i++) for(int j=1;j<=500;j++) p[i][j] = '.';
        for(int i=1;i<=250;i++) p[1][i] = p[i][1] = 'I';
        for(int i=251;i<=500;i++) p[500][i] = p[i][500] = 'I';
        for(int i=1;i<=10000;i++){
            int x = random(2,499), y = random(2,499);
            while(p[x][y]=='S') x = random(2,499), y = random(2,499);
            p[x][y] = 'S';
        }
        out << 500 << ' ' << 500 << endl;
        for(int i=1;i<=500;i++){
            for(int j=1;j<=500;j++){
                out << p[i][j];
            }
            out << endl;
        }
    }
}