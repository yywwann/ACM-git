#include <iostream>
#include <string>
#include <string.h>
#include <algorithm>
using namespace std;

struct studentM{
	string name,id;
	char gender;
	int grade;
}male[50005];
struct studentF{
	string name,id;
	char gender;
	int grade;
}female[50005];
bool cmp1(studentM a,studentM b){
	return a.grade<b.grade;
}
bool cmp2(studentF a,studentF b){
	return a.grade>b.grade;
}

int main(){
	int t;
	cin>>t;
	while(t--){
		int n,grade,m=0,f=0;
		string name,id;
		char gender;
		cin>>n;
		for(int i=0;i<n;i++){
			cin>>name>>gender>>id>>grade;
			if(gender=='M'){
				m++;
				male[m].name=name;
				male[m].gender=gender;
				male[m].id=id;
				male[m].grade=grade;
			}
			else{
				f++;
				female[f].name=name;
				female[f].gender=gender;
				female[f].id=id;
				female[f].grade=grade;
			}
		}
		sort(male+1,male+m+1,cmp1);
		sort(female+1,female+f+1,cmp2);
		if(f==0) cout<<"Miss"<<endl;
		else cout<<female[1].name<<" "<<female[1].id<<endl;
		if(m==0) cout<<"Miss"<<endl;
		else cout<<male[1].name<<" "<<male[1].id<<endl;
		if(m==0||f==0) cout<<"Null"<<endl;
		else cout<<female[1].grade-male[1].grade<<endl;
	} 
	
	return 0;
}
